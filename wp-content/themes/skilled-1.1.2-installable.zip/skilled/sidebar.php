<?php
dynamic_sidebar( 'wheels-sidebar-primary' );
