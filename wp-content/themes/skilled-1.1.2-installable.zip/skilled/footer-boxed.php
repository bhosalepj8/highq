<?php get_template_part( 'templates/footer' ); ?>
</div> <?php // close wh-main-wrap ?>
<?php wp_footer(); ?>
</body>
</html>
