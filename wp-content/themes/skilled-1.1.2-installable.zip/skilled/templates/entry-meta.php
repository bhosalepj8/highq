<div class="entry-meta">
	<?php skilled_entry_meta(); ?>
</div>
