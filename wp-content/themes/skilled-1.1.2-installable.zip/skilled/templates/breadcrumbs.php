<?php if ( ! skilled_is_search_courses() && function_exists( 'breadcrumb_trail' ) ): ?>
	<div class="<?php echo skilled_class( 'breadcrumbs' ); ?>">
		<?php breadcrumb_trail( array( 'show_browse' => false ) ); ?>
	</div>
<?php endif; ?>
