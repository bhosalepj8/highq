<?php 
comment_form(); 
posts_nav_link();
paginate_links();
the_posts_pagination();
next_posts_link();
previous_posts_link();
?>